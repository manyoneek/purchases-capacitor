#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
mkdir -p worktrees/purchases-capacitor
tar -xzf sdk-source.tar.gz -C worktrees/purchases-capacitor
if [ "$variant" = fixed ]; then (cd worktrees/purchases-capacitor && patch -p1 < ../../fixes/capacitor-null.patch); fi
(cd worktrees/purchases-capacitor && corepack yarn install --frozen-lockfile && npm run build)
(cd app && npm install --legacy-peer-deps && npm run build && npx cap sync ios)
(cd app/ios/App && xcodebuild build -project App.xcodeproj -scheme App -destination "platform=iOS Simulator,id=${QA_SIMULATOR:?Set QA_SIMULATOR}" -derivedDataPath ../../../derived-app IPHONEOS_DEPLOYMENT_TARGET=27.0 CODE_SIGNING_ALLOWED=NO)
python3 capture-app.py "$variant"
