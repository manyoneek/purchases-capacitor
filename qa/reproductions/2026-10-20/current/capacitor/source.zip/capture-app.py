import subprocess,pathlib,os,json,sys,time,signal,select
r=pathlib.Path(__file__).parent;stage=sys.argv[1];env=os.environ.copy();env['DEVELOPER_DIR']='/Applications/Xcode-27.1.0-release.candidate.app/Contents/Developer';device=os.environ.get('QA_SIMULATOR','286DC73D-2455-4F1B-A4A2-56E3BDEE64D9');appId='com.revenuecat.sdkbugreporter.capacitorplacement'
def cmd(args,check=True):return subprocess.run(['xcrun','simctl']+args,env=env,check=check,capture_output=True,text=True)
cmd(['boot',device],False);cmd(['bootstatus',device,'-b']);cmd(['install',device,os.environ.get('QA_APP_PATH',str(r/'derived-app/Build/Products/Debug-iphonesimulator/App.app'))]);cmd(['terminate',device,appId],False)
vlog=(r/'logs'/f'{stage}-video.log').open('w');video=subprocess.Popen(['xcrun','simctl','io',device,'recordVideo','--display=1','--codec=h264','--force',str(r/'evidence'/f'{stage}.mp4')],env=env,stdout=vlog,stderr=subprocess.STDOUT)
time.sleep(1)
log=(r/'logs'/f'app-{stage}-runtime.log').open('w');p=subprocess.Popen(['xcrun','simctl','launch','--console-pty','--terminate-running-process',device,appId],env=env,stdout=log,stderr=subprocess.STDOUT)
container=pathlib.Path(cmd(['get_app_container',device,appId,'data']).stdout.strip()); resultFile=container/'Documents/results.json'
if resultFile.exists():resultFile.unlink()
result=None
try:
 for i in range(90):
  time.sleep(1);s=(r/'logs'/f'app-{stage}-runtime.log').read_text(errors='replace')
  if resultFile.exists():
   result=json.loads(resultFile.read_text());break
  if 'QA_RESULT ' in s:
   line=s.split('QA_RESULT ')[-1].splitlines()[0]
   try:result=json.JSONDecoder().raw_decode(line)[0]
   except Exception:continue
   break
 time.sleep(3)
 cmd(['io',device,'screenshot','--display=1',str(r/'evidence'/f'{stage}.png')])
 if result is None:raise RuntimeError('No QA_RESULT from native app; inspect runtime log')
 (r/'evidence'/f'{stage}-results.json').write_text(json.dumps(result,indent=2));print(result)
finally:
 video.send_signal(signal.SIGINT);video.wait(timeout=20);vlog.close();p.terminate();p.wait(timeout=15);log.close()
