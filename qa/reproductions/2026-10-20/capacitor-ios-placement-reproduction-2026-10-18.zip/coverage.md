# Functional QA coverage — 2026-10-18

## Inventory and selection

Refreshed all 77 public RevenueCat repositories via paginated public org API, including 21 forks and 3 archives. All 77 existing clone origins verified; zero missing/new clones or failures. Original clones retain their initial clean statuses. Reviews use separate detached worktrees at fetched default branches.

- purchases-ios: `c9e25b75dd6215856f30420d8c566d16ee29b045`. Reviewed SubscriptionPeriod/ISOPeriodFormatter and Test Store product conversion paths: nulls, units, introductory prices/trials, missing purchase options/base prices, and availability errors. Existing four selected suites: 21 passed on macOS. Added five focused actual-implementation cases: empty options, absent base price, null description/missing default, zero-priced consumable, quarterly base with incomplete intro phase. Selected suite now 26 passed. No defect confirmed in this bounded review; full SDK suite was not run.
- purchases-capacitor: `4c2567777acf8f9361bd830d25868cc16496ab46` (13.7.4). Reviewed JS proxy/error normalization and result contracts; iOS offering/placement completion, configuration, product/purchase input validation, listeners, nullable currency cache, attribute forwarding, refund helper; adjacent Android nullable completion path source only. Baseline JS 17 passed and TypeScript check passed; existing iOS helper XCTest suite 2 passed. Confirmed one new fingerprint: `capacitor:ios-placement:nil-success-resolves-undefined-not-null`.
- purchases-android was fetched into a candidate worktree but no core implementation review/test coverage is claimed. Java discovery confirms no registered runtime; no Android tests attempted. Next rotation: purchases-android (resolve toolchain or rotate if still unavailable).

## Confirmed defect and tests

No Offering placement returns undefined despite the nullable public type. Added six JS wrapper cases: four controls pass/two contract checks fail before. Temporary scoped success normalization makes all six pass and the full suite pass 23/23. Error/listener baseline tests remain green; strict TypeScript consumer and project typecheck pass. After restoring source, full suite returns 21 pass / 2 fail. Production source restored byte-for-byte; only regression/type fixtures remain in isolated worktree. No production source edits in purchases-ios.

Actual native app uses the reviewed TypeScript entry point and native plugin, Capacitor 8.4.1, shared SDK 19.12.0 and iOS SDK 5.95.0. Configure -> getCustomerInfo -> getOfferings -> non-null fallback placement -> explicit No Offering placement. Before: 4 pass / 2 fail; after: 6 pass / 0 fail. No callback injection or mocked transport in app. Both ~9.5 second videos and screenshots visually inspected. Independently built staged source app also reproduces 4/2. Standalone archived SDK/source, fix, tests, commands, runtime logs and dependency lockfile retained.

## Dedicated service setup

Used only SDK Bug Reporter proj602cc762, Test Store app4ca00b430f, synthetic users. Created targeting rule tvpeenTzcQ: `sdk_bug_reporter_none_20261018` -> No Offering; all other cases -> existing default. Default offering/products unchanged. Official CLI has no placement management command, so used managed browser dashboard and verified via official `rc offerings preview`. Setup and rule URL saved in synthetic-setup.json. No purchases/refunds, other projects or customer accounts. Closed only the new browser tab.

## Introduction and duplicates

Searched public issues/PRs for nullable/placement terms. #568 concerns selection in presented paywalls, not this return value. #628 is the earlier rejection fix and the introduction of the current undefined-success behavior. Exact commit 8365ed83ea234fb65772d0bd08fb343746cfd382, 2025-12-17; first containing stable source release 11.3.1 published 2025-12-18. Parent c468cc0085b75a955dd141ea27a62a6abf312823 rejects nil. Original feature #222 already declared null. Parent is not represented as a passing baseline.

Executed original helper bodies from parent, introducing commit and current source with actual Capacitor 7.0.0 resolve/serialization implementation on macOS. Missing framework declarations are shims; no historical full app/backend run. All present-offering controls preserve their value. Historical dependency range allowed 7.0.0 but no lockfile proves the originally resolved version. Current native app is independently verified on iOS simulator. Full historical source, hashes and compile commands preserved.

Refund cancellation candidate was ruled out in source: the shared refund path omits userCancelled on ordinary errors and adds true only for cancellation. No fabricated false-flag payload is reported as a reachable defect. Prior nine fingerprints preserved; no duplicate report.

## Harness/tooling corrections and limits

ripgrep unavailable: used grep/Python. Command-line developer directory initially pointed to CommandLineTools; set DEVELOPER_DIR only in task subprocesses. The generated Capacitor app template lacked the UIScene lifecycle required by iOS 27; captured crash and fixed app lifecycle before any SDK claim. Initial screenshot selected inactive Duo display; final capture explicitly uses display 1. First candidate run used an unknown placement and correctly returned fallback; preserved as setup-control evidence, not a bug. Added explicit No Offering rule before confirmation. Added UTF-8 metadata and a direct non-null placement control before final captures. Focused TypeScript CLI hit TS5112; retried with a narrow config extending the SDK config, passed. Historical tar extraction adjusted to installed Python version. All recovered; no unresolved build failures.

Native mobile execution is iOS 27.1 simulator only. No physical-device, Android or purchase-flow claim. Only one defect met reporting requirements. No issues, PRs, comments, pushes, vendor/support requests, schedule changes or duplicate Discord sends. Delivery is scheduled final only to channel 1559550752349884437; no in-run delivery receipt.

Standalone runner verification caught git apply silently leaving the file unchanged inside the enclosing workspace repository. Changed only the delivery runner to use patch -p1 with an explicit changed-file assertion; independent --fixed --tests retry passes 23/23, and the runner restores the archived source bytes. Original failing runner log retained.
