import { Purchases } from '../worktrees/purchases-capacitor/src/index';
import { apiKey } from './config';
const output = document.getElementById('output')!;
const rows: { name: string; passed: boolean; detail: string }[] = [];
function check(name: string, passed: boolean, detail: string) {
  rows.push({name, passed, detail});
  output.innerHTML = rows.map(r => `<section class="${r.passed ? 'pass' : 'fail'}"><b>${r.passed ? 'PASS' : 'FAIL'} · ${r.name}</b><p>${r.detail}</p></section>`).join('');
}
async function run() {
  output.textContent = 'Configuring a synthetic Test Store user…';
  try {
    await Purchases.configure({apiKey, appUserID: 'sdk-bug-reporter-placement-20261018-' + Date.now()});
    check('Actual SDK configured', (await Purchases.isConfigured()).isConfigured, 'iOS · Test Store · SDK Bug Reporter');
    const info = await Purchases.getCustomerInfo();
    check('Customer info received', !!info.customerInfo.originalAppUserId, 'Live Test Store response; no injected callbacks');
    const offerings = await Purchases.getOfferings();
    check('Non-empty offering control', !!offerings.current?.identifier, 'Current offering: ' + offerings.current?.identifier);
    const fallback = await Purchases.getCurrentOfferingForPlacement({placementIdentifier: 'sdk_bug_reporter_fallback_control'});
    check('Placement fallback preserved', fallback?.identifier === offerings.current?.identifier, 'Unknown placement still resolves to default');
    const placement = await Purchases.getCurrentOfferingForPlacement({placementIdentifier: 'sdk_bug_reporter_none_20261018'});
    check('No-offering placement returns null', placement === null, 'Expected null; received ' + String(placement) + ' (typeof ' + typeof placement + ')');
    try {
      const label = placement !== null ? placement.identifier : 'No offering';
      check('Documented null guard is safe', label === 'No offering', 'Consumer result: ' + label);
    } catch (error) { check('Documented null guard is safe', false, String(error)); }
  } catch (error) {check('Supported flow completed', false, String(error));}
  const result = {sdk:'purchases-capacitor',platform:'iOS simulator',project:'proj602cc762',app:'app4ca00b430f',rows,passed:rows.filter(x=>x.passed).length,failed:rows.filter(x=>!x.passed).length};
  console.log('QA_RESULT ' + JSON.stringify(result));
  (window as any).webkit.messageHandlers.qaEvidence.postMessage(result);
  document.body.dataset.complete = 'true';
}
setTimeout(run, 2000);
