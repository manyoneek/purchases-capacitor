import UIKit
import WebKit
import Capacitor

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool { true }
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = EvidenceViewController()
        self.window = window
        window.makeKeyAndVisible()
    }
}

class EvidenceViewController: CAPBridgeViewController, WKScriptMessageHandler {
    override func capacitorDidLoad() {
        bridge?.webView?.configuration.userContentController.add(self, name: "qaEvidence")
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "qaEvidence", JSONSerialization.isValidJSONObject(message.body) else { return }
        do {
            let data = try JSONSerialization.data(withJSONObject: message.body, options: [.prettyPrinted, .sortedKeys])
            let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            try data.write(to: directory.appendingPathComponent("results.json"), options: .atomic)
        } catch { print("QA evidence write failed: \(error)") }
    }
}
