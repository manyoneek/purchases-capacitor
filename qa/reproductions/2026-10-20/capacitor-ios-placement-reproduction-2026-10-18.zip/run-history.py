import pathlib,subprocess,os,json,hashlib
r=pathlib.Path(__file__).parent;h=r/'history';cap=h/'capacitor7';w=r/'worktrees/purchases-capacitor'
env=os.environ.copy();# Inherit DEVELOPER_DIR or the selected Xcode.
def method(source,signature):
 start=source.index(signature);brace=source.index('{',start);depth=1;i=brace+1
 while depth:
  depth+=(source[i]=='{')-(source[i]=='}');i+=1
 return source[start:i]
capCall=(cap/'CAPPluginCall.swift').read_text()
methods='\n'.join(method(capCall,s) for s in ['func resolve()','func resolve(_ data:','func reject(_ message:'])
base='''
import Foundation
class CAPLog { static func print(_ values: Any...) { fatalError("Unexpected serialization failure: \(values)") } }
class ErrorContainer { let message="unused"; let code=0; let error=NSError(domain:"qa",code:0);let info:[String:Any]=[:] }
class PurchasesPlugin { func rejectWithErrorContainer(_ call:CAPPluginCall,error:ErrorContainer) { fatalError("Unexpected error fixture") } }
class CAPPluginCall: NSObject {
 var successHandler: (CAPPluginCallResult,CAPPluginCall)->Void
 var errorHandler: (CAPPluginCallError)->Void
 init(success:@escaping(CAPPluginCallResult,CAPPluginCall)->Void,error:@escaping(CAPPluginCallError)->Void){successHandler=success;errorHandler=error}
'''+methods+'\n}\n'
results=[];provenance=[]
for label in ['parent','introduced','current']:
 source=(h/f'{label}-ios_Sources_RevenuecatPurchasesCapacitor_PluginHelperExtensions.swift').read_text() if label!='current' else (w/'ios/Sources/RevenuecatPurchasesCapacitor/PluginHelperExtensions.swift').read_text()
 methodName='getCompletionBlockHandler' if label=='parent' else 'getNullableCompletionBlockHandler'
 extracted=method(source,'func '+methodName+'(')
 src=h/f'{label}-boundary';src.mkdir(exist_ok=True)
 (src/'Boundary.swift').write_text(base+'\ninternal extension PurchasesPlugin {\n'+extracted+'\n}\n')
 main='''
import Foundation
var rows:[[String:Any]]=[]
for (name,response) in [("nil",nil),("offering",["identifier":"control"])] as [(String,[String:Any]?)] {
 let call=CAPPluginCall(success:{ result,_ in
  let call=JSCall(options:[:],pluginId:"Purchases",method:"getCurrentOfferingForPlacement",callbackId:"1")
  rows.append(["case":name,"status":"resolved","javascriptPayload":JSResult(call:call,callResult:result).jsonPayload()])
 },error:{ error in rows.append(["case":name,"status":"rejected","message":error.message]) })
 PurchasesPlugin().METHOD(call)(response,nil)
}
let data=try JSONSerialization.data(withJSONObject:rows,options:[.sortedKeys])
print(String(data:data,encoding:.utf8)!)
'''.replace('METHOD',methodName)
 (src/'main.swift').write_text(main)
 cmd=['xcrun','swiftc',str(cap/'PluginCallResult.swift'),str(cap/'JS.swift'),str(src/'Boundary.swift'),str(src/'main.swift'),'-o',str(src/'run')]
 p=subprocess.run(cmd,env=env,capture_output=True,text=True);(r/'logs'/f'history-{label}-compile.log').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(p.stderr)
 p=subprocess.run([str(src/'run')],capture_output=True,text=True,check=True);rows=json.loads(p.stdout);(src/'results.json').write_text(json.dumps(rows,indent=2));results.append(dict(revision=label,results=rows))
 provenance.append(dict(label=label,method=methodName,methodSHA256=hashlib.sha256(extracted.encode()).hexdigest(),compilerCommand=cmd))
(h/'boundary-results.json').write_text(json.dumps(results,indent=2));(h/'boundary-provenance.json').write_text(json.dumps(provenance,indent=2));print(json.dumps(results,indent=2))
