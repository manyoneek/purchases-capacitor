
import Foundation
class CAPLog { static func print(_ values: Any...) { fatalError("Unexpected serialization failure: \(values)") } }
class ErrorContainer { let message="unused"; let code=0; let error=NSError(domain:"qa",code:0);let info:[String:Any]=[:] }
class PurchasesPlugin { func rejectWithErrorContainer(_ call:CAPPluginCall,error:ErrorContainer) { fatalError("Unexpected error fixture") } }
class CAPPluginCall: NSObject {
 var successHandler: (CAPPluginCallResult,CAPPluginCall)->Void
 var errorHandler: (CAPPluginCallError)->Void
 init(success:@escaping(CAPPluginCallResult,CAPPluginCall)->Void,error:@escaping(CAPPluginCallError)->Void){successHandler=success;errorHandler=error}
func resolve() {
        successHandler(CAPPluginCallResult(nil), self)
    }
func resolve(_ data: PluginCallResultData = [:]) {
        successHandler(CAPPluginCallResult(data), self)
    }
func reject(_ message: String, _ code: String? = nil, _ error: Error? = nil, _ data: PluginCallResultData? = nil) {
        errorHandler(CAPPluginCallError(message: message, code: code, error: error, data: data))
    }
}

internal extension PurchasesPlugin {
func getNullableCompletionBlockHandler(_ call: CAPPluginCall,
                                           wrapperKey: String? = nil) -> (([String: Any]?, ErrorContainer?) -> Void) {
        func handleResponse(response: [String: Any]?, error: ErrorContainer?) {
            if let error {
                rejectWithErrorContainer(call, error: error)
            } else if let response {
                let mapToResolve: [String: Any] = {
                    if let wrapperKey {
                        return [wrapperKey: response]
                    } else {
                        return response
                    }
                }()
                call.resolve(mapToResolve)
            } else {
                call.resolve()
            }
        }
        return handleResponse
    }
}
