
import Foundation
var rows:[[String:Any]]=[]
for (name,response) in [("nil",nil),("offering",["identifier":"control"])] as [(String,[String:Any]?)] {
 let call=CAPPluginCall(success:{ result,_ in
  let call=JSCall(options:[:],pluginId:"Purchases",method:"getCurrentOfferingForPlacement",callbackId:"1")
  rows.append(["case":name,"status":"resolved","javascriptPayload":JSResult(call:call,callResult:result).jsonPayload()])
 },error:{ error in rows.append(["case":name,"status":"rejected","message":error.message]) })
 PurchasesPlugin().getCompletionBlockHandler(call)(response,nil)
}
let data=try JSONSerialization.data(withJSONObject:rows,options:[.sortedKeys])
print(String(data:data,encoding:.utf8)!)
