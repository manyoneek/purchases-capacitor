import type { PurchasesPlugin } from './src/definitions';
type Placement = Awaited<ReturnType<PurchasesPlugin['getCurrentOfferingForPlacement']>>;
export function renderPlacement(offering: Placement): string {
  return offering !== null ? offering.identifier : 'No offering';
}
