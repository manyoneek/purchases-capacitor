#!/usr/bin/env python3
import os,pathlib,subprocess,sys,shutil,json
root=pathlib.Path(__file__).resolve().parent; sdk=root/'worktrees/purchases-capacitor'; app=root/'app'; fixed='--fixed' in sys.argv; tests='--tests' in sys.argv;env=os.environ.copy()
if not sdk.exists():
 sdk.mkdir(parents=True);subprocess.run(['tar','-xzf',str(root/'purchases-capacitor-source.tar.gz'),'-C',str(sdk)],check=True)
def run(cmd,cwd):subprocess.run(cmd,cwd=cwd,env=env,check=True)
if not (sdk/'node_modules').exists():run(['corepack','yarn','install','--frozen-lockfile'],sdk)
if not (app/'node_modules').exists():run(['npm','ci','--legacy-peer-deps'],app)
p=sdk/'src/index.ts';original=p.read_bytes()
try:
 if fixed:
  run(['patch','-p1','--forward','--batch','-i',str(root/'suggested-fix.patch')],sdk)
  assert p.read_bytes() != original, 'Fix patch did not change SDK source'
 if tests:
  shutil.copy2(root/'tests/placementNullContract.test.ts',sdk/'__tests__/placementNullContract.test.ts')
  for name in ['qa-placement-consumer.ts','tsconfig.qa-placement.json']:shutil.copy2(root/'tests'/name,sdk/name)
  run(['./node_modules/.bin/tsc','-p','tsconfig.qa-placement.json'],sdk)
  run(['npm','test','--','--runInBand'],sdk)
 else:
  run(['npm','run','build'],app);run(['npx','cap','sync','ios'],app)
  dest=os.environ.get('QA_DESTINATION','generic/platform=iOS Simulator')
  run(['xcodebuild','build','-project','App.xcodeproj','-scheme','App','-destination',dest,'-derivedDataPath',str(root/'derived'),'CODE_SIGNING_ALLOWED=NO'],app/'ios/App')
  print('Built:',root/'derived/Build/Products/Debug-iphonesimulator/App.app')
finally:p.write_bytes(original)
