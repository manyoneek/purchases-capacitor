# Capacitor iOS no-offering placement reproduction

Actual SDK source: see `SOURCE_COMMIT.txt`. Configured for SDK Bug Reporter / Test Store (`proj602cc762`, `app4ca00b430f`). The saved test setup is in `synthetic-setup.json`.

## Build and run

Requires macOS, Xcode with an iOS simulator, Node/npm and Corepack. Select Xcode normally or set `DEVELOPER_DIR` to your Xcode `Contents/Developer` directory.

```sh
python3 reproduce.py                  # unmodified SDK, builds App.app
# Set SIMULATOR_ID to an available iOS simulator UDID from xcrun simctl list devices.
xcrun simctl boot "$SIMULATOR_ID"       # omit if already booted
xcrun simctl install "$SIMULATOR_ID" derived/Build/Products/Debug-iphonesimulator/App.app
xcrun simctl launch "$SIMULATOR_ID" com.revenuecat.sdkbugreporter.capacitorplacement
```

The app runs automatically: configure a unique synthetic user, fetch real customer info/offerings, test a fallback placement, and test the explicit No Offering placement. Expected baseline: 4 green checks and 2 red checks. Results are also written to the app's Documents/results.json.

```sh
python3 reproduce.py --fixed          # rebuild with suggested fix; 6 green checks
python3 reproduce.py --tests          # expected: 2 failures in 23 JS tests
python3 reproduce.py --fixed --tests  # all 23 pass
```

Each invocation temporarily applies the fix if requested and restores the SDK source afterward. Reinstall the rebuilt App.app to switch versions. Every launch uses a new synthetic user. The patch changes only the public JS wrapper; native dependencies and the test setup stay the same.

`purchases-capacitor-source.tar.gz` contains the exact affected checkout. The runner extracts it under worktrees/ on first use. The native project links this local implementation through SPM. The web bundle imports the same checkout's real TypeScript entry point. The app's native evidence handler only records results; it does not alter SDK calls, callbacks or network responses.

The public Test Store SDK key is in app/config.ts. To reuse another authorized synthetic setup, change that file and the placement in app/src.ts. This delivered setup requires no purchases.

See reports/01-capacitor-null-placement.md for test commands/results, history, impact and limitations. Historical boundary tests do not claim full historical app reproduction.

## Historical boundary check

After extracting/installing through reproduce.py, run `python3 run-history.py`. This executes historical native method bodies with actual Capacitor 7.0.0 serialization code on macOS. Missing framework declarations are supplied by the harness. It does not run a historical mobile app. The parent rejects nil; the introducing/current helpers resolve JavaScript `undefined`; all present-offering controls are preserved.
